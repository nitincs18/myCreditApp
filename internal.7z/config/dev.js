

module.exports={
    googleClientID:'311862843748-4s534nvtao79ofsh3bs24r7n7g4rkv5v.apps.googleusercontent.com',
    googleClientSecret:'d9k2z4N-ESsFqhKad52mDIe8',
    mongoURI:'mongodb://sa:ab_TAK56@ds225253.mlab.com:25253/node-react',
    cookieKey: 'vyetfwgdkhsntvhdfgbhnmhjbnkghbgvnhkj'
}